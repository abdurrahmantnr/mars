<?php
/**
 * Plugin Name: Mars Custom Login & Maintenance Mode
 * Description: Özelleştirilmiş giriş sayfası, yapım aşamasında modu ve dinamik copyright shortcodu.
 * Version: 1.0
 * Author: Mars Creative
 * Author URI: https://marscreative.com.tr/
 */

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'includes/settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/maintenance.php';
require_once plugin_dir_path(__FILE__) . 'includes/shortcode.php';

// Redirect default login
add_action('init', function () {
    $custom_login_slug = get_option('mars_custom_login_url', 'ozel-giris');
    $request_uri = $_SERVER['REQUEST_URI'];

    if (strpos($request_uri, 'wp-login.php') !== false || (strpos($request_uri, 'wp-admin') !== false && !is_user_logged_in())) {
        wp_redirect(home_url());
        exit;
    }

    if (preg_match("~^/{$custom_login_slug}/?$~", $request_uri)) {
        require_once ABSPATH . 'wp-login.php';
        exit;
    }
});
