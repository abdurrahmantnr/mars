<?php
if (!defined('ABSPATH')) exit;

add_action('template_redirect', function () {
    if (!is_user_logged_in() && get_option('mars_maintenance_mode')) {
        status_header(503);
        include plugin_dir_path(__FILE__) . '../assets/maintenance-template.php';
        exit;
    }
});
