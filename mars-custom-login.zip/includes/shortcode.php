<?php
if (!defined('ABSPATH')) exit;

add_shortcode('mars_copyright', function () {
    $year = date('Y');
    $agency = esc_html(get_option('mars_agency_name', 'Marstasu Web Tasarım Ajansı'));
    return "Copyright© {$year}, All rights reserved. Powered by {$agency}.";
});
