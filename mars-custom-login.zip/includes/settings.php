<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_options_page('Mars Custom Login Ayarları', 'Mars Login', 'manage_options', 'mars-custom-login', 'mars_custom_login_settings_page');
});

add_action('admin_init', function () {
    register_setting('mars_custom_login_settings', 'mars_custom_login_url');
    register_setting('mars_custom_login_settings', 'mars_maintenance_mode');
    register_setting('mars_custom_login_settings', 'mars_agency_name');
});

function mars_custom_login_settings_page() {
?>
<div class="wrap">
    <h1>Mars Custom Login Ayarları</h1>
    <form method="post" action="options.php">
        <?php
        settings_fields('mars_custom_login_settings');
        do_settings_sections('mars_custom_login_settings');
        ?>
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Özel Giriş URL'si</th>
                <td><input type="text" name="mars_custom_login_url" value="<?php echo esc_attr(get_option('mars_custom_login_url', 'ozel-giris')); ?>" /></td>
            </tr>
            <tr valign="top">
                <th scope="row">Yapım Aşamasında Modu</th>
                <td><input type="checkbox" name="mars_maintenance_mode" value="1" <?php checked(1, get_option('mars_maintenance_mode'), true); ?> /></td>
            </tr>
            <tr valign="top">
                <th scope="row">Ajans Adı (Footer için)</th>
                <td><input type="text" name="mars_agency_name" value="<?php echo esc_attr(get_option('mars_agency_name', 'Marstasu Web Tasarım Ajansı')); ?>" /></td>
            </tr>
        </table>
        <?php submit_button(); ?>
    </form>
</div>
<?php }
