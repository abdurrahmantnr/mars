<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Site Yapım Aşamasında</title>
    <style>
        body { font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: #f7f7f7; }
        .container { display: flex; width: 80%; background: white; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .left, .right { width: 50%; padding: 40px; box-sizing: border-box; }
        .left img { max-width: 200px; }
        .left h1 { font-size: 24px; margin: 20px 0 10px; }
        .left p { font-size: 16px; }
        .left a { display: inline-block; margin-top: 20px; background: #000; color: #fff; padding: 10px 20px; text-decoration: none; }
        .right img { max-width: 100%; height: auto; }
    </style>
</head>
<body>
    <div class="container">
        <div class="left">
            <img src="<?php echo plugin_dir_url(__FILE__); ?>logo.png" alt="Logo">
            <h1>Site Yapım Aşamasında</h1>
            <p>Yeni tasarımımızla çok yakında karşınızdayız. Lütfen daha sonra tekrar ziyaret edin.</p>
            <a href="/wp-login.php">Giriş Yap</a>
        </div>
        <div class="right">
            <img src="<?php echo plugin_dir_url(__FILE__); ?>yapim.jpeg" alt="Görsel">
        </div>
    </div>
</body>
</html>
